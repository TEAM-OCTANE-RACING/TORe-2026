%% Load Steering parameters

Steering = struct();

Steering.d = 61.543;              % Rack offset (Y-distance from Kingpin axis)
Steering.L = 351;                 % Tie rod length 
Steering.R = 61.3;                % Steering arm length
Steering.theta1 = 90 - 83.625;    % Steering arm neutral angle(6.375 deg from longitudinal axis)
Steering.spindle_length = 44.075; % Distance from kingpin to outer wheel center