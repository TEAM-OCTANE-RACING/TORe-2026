% =========================================================================
% YMD GENERATOR - Live Snapshot Method (Full Delta & Beta Sweep)
% =========================================================================
clc;
% close all;

% --- 1. Test Setup ---
modelName = 'Vehicle_Model_999_Modular_roll_gradient';
set_param(modelName, 'FastRestart', 'on');
if ~bdIsLoaded(modelName), load_system(modelName); end

if ~evalin('base', 'exist(''Par'', ''var'')')
    error('Please load the vehicle parameters (Par) into the workspace first.');
end
Par = evalin('base', 'Par');

v_target  = 15;                     

% Sweep Arrays
steer_deg_array = -25:10:25; % Steering sweep (Adjust step size for more/fewer lines)
beta_deg_array = -25:10:25;  % Body slip sweep

num_steer = length(steer_deg_array);
num_beta  = length(beta_deg_array);

% Generate Colormap for distinguishing steering angles
colors = turbo(num_steer);

fprintf('--- Starting Full Live Snapshot YMD Generation ---\n');
fprintf('Velocity       : %.2f m/s\n', v_target);
fprintf('Total Steer Angles : %d\n', num_steer);
fprintf('Sweeping Beta from %d to %d deg...\n\n', min(beta_deg_array), max(beta_deg_array));

% --- 2. Initialize Live Figure ---
figure('Name', 'Full Live Snapshot YMD', 'Color', 'w', 'Position', [100, 100, 1000, 700]);
hold on; grid on;

title(sprintf('Yaw Moment Diagram: \\delta Sweep (-25\\circ to +25\\circ), V = %.1f m/s', v_target), 'FontSize', 13);
xlabel('Lateral Acceleration (m/s^2)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Yaw Moment (Nm)', 'FontSize', 12, 'FontWeight', 'bold');

ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';

% Pre-plot subtle dashed zero-lines
plot(xlim, [0 0], 'k--', 'LineWidth', 1, 'HandleVisibility', 'off'); 
plot([0 0], ylim, 'k--', 'LineWidth', 1, 'HandleVisibility', 'off'); 

% --- 3. Outer Iteration Loop (Steering) ---
for s = 1:num_steer
    steer_deg = steer_deg_array(s);
    steer_rad = deg2rad(steer_deg);
    
    fprintf('Plotting Steer = %3d deg...\n', steer_deg);
    
    curve_ay = zeros(1, num_beta);
    curve_mz = zeros(1, num_beta);
    
    % Initialize live plot handles for THIS specific steering angle
    h_scatter = scatter(NaN, NaN, 15, [0.7 0.7 0.7], 'filled', 'HandleVisibility', 'off'); % Hide raw dots from legend
    h_line = plot(NaN, NaN, '-', 'Color', colors(s,:), 'LineWidth', 2, 'DisplayName', sprintf('\\delta = %d\\circ', steer_deg));
    
    % --- 4. Inner Iteration Loop (Beta) ---
    for b = 1:num_beta
        current_beta = beta_deg_array(b);
        init_vy = v_target * tan(deg2rad(current_beta));
        
        simIn = Simulink.SimulationInput(modelName);
        simIn = simIn.setModelParameter('SimulationMode', 'accelerator');
        simIn = simIn.setModelParameter('StopTime', '0.05'); 
        simIn = simIn.setModelParameter('MaskedZcDiagnostic', 'none');
        
        simIn = simIn.setVariable('init_vx', v_target);
        simIn = simIn.setVariable('init_vy', init_vy);
        simIn = simIn.setVariable('init_r', 0);           
        simIn = simIn.setVariable('vel_ggv', v_target);   
        simIn = simIn.setVariable('steer_ggv', steer_rad); 
        
        out = sim(simIn);
        
        % Extract Data safely
        try lat_accel_trace = out.Lateral_accln_sensor.Data; catch, lat_accel_trace = out.Lateral_accln.Data; end
        yaw_moment_trace = out.Yaw_moment.Data;
        try time_array = out.tout; catch, time_array = out.get('tout'); end
        
        % Take snapshot at t = 0.02s (tire relaxation saturation)
        t_snapshot = 0.02;
        snap_idx = find(time_array >= t_snapshot, 1);
        if isempty(snap_idx), snap_idx = length(time_array); end 
        
        ay_val = lat_accel_trace(snap_idx);
        mz_val = yaw_moment_trace(snap_idx);
        
        % NaN/Inf Guard
        if isnan(ay_val) || isinf(ay_val), ay_val = 0; end
        if isnan(mz_val) || isinf(mz_val), mz_val = 0; end
        
        curve_ay(b) = ay_val;
        curve_mz(b) = mz_val;
        
        % LIVE PLOT UPDATE
        h_scatter.XData = curve_ay(1:b);
        h_scatter.YData = curve_mz(1:b);
        h_line.XData    = curve_ay(1:b);
        h_line.YData    = curve_mz(1:b);
        drawnow; 
    end
    
    % --- 5. CLEAN ENVELOPE TRIMMING ---
    % Find the absolute lateral limits to slice off the curling ends
    [~, idx_left_limit]  = min(curve_ay);
    [~, idx_right_limit] = max(curve_ay);
    
    start_idx = min(idx_left_limit, idx_right_limit);
    end_idx   = max(idx_left_limit, idx_right_limit);
    
    clean_ay = curve_ay(start_idx:end_idx);
    clean_mz = curve_mz(start_idx:end_idx);
    
    % Final update: Lock the line strictly to the clean envelope
    h_line.XData = clean_ay;
    h_line.YData = clean_mz;
    
    % Remove the raw scatter points completely once the line is locked
    delete(h_scatter);
    
    % Highlight Anchor Point (Beta = 0) and add text label
    idx_zero = find(beta_deg_array == 0, 1);
    if ~isempty(idx_zero)
        % Plot anchor point (hidden from legend to avoid clutter)
        scatter(curve_ay(idx_zero), curve_mz(idx_zero), 30, 'k', 'filled', 'HandleVisibility', 'off');
        
        % Add steer angle label directly onto the plot
        text(curve_ay(idx_zero), curve_mz(idx_zero), sprintf(' %d\\circ', steer_deg), ...
            'Color', colors(s,:), 'FontSize', 9, 'VerticalAlignment', 'bottom');
    end
end

set_param(modelName, 'FastRestart', 'off');
fprintf('\nDone. Full YMD envelope map generated.\n');