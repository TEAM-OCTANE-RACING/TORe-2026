% =========================================================================
% YMD GENERATOR - Live Snapshot Method (Foolproof Clean Envelope)
% =========================================================================
clc;
close all;

% --- 1. Test Setup ---
modelName = 'Vehicle_Model_999_Modular_roll_gradient';

set_param(modelName, 'FastRestart', 'on');

if ~bdIsLoaded(modelName), load_system(modelName); end

if ~evalin('base', 'exist(''Par'', ''var'')')
    error('Please load the vehicle parameters (Par) into the workspace first.');
end
Par = evalin('base', 'Par');

v_target  = 15;                     
steer_deg = 20; % Single steering angle for test
beta_deg_array = -25:1:25; % Full sweep from -25 to +25 degrees

num_beta = length(beta_deg_array);
steer_rad = deg2rad(steer_deg);

curve_ay = zeros(1, num_beta);
curve_mz = zeros(1, num_beta);

fprintf('--- Starting Live Snapshot YMD Generation ---\n');

% --- 2. Initialize Live Figure ---
figure('Name', 'Live Snapshot YMD', 'Color', 'w', 'Position', [100, 100, 800, 600]);
hold on; grid on;

title(sprintf('Live Snapshot YMD: \\delta = %.1f\\circ, V = %.1f m/s', steer_deg, v_target), 'FontSize', 13);
xlabel('Lateral Acceleration (m/s^2)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Yaw Moment (Nm)', 'FontSize', 12, 'FontWeight', 'bold');

ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';

% Scatter for raw points
h_scatter = scatter(NaN, NaN, 25, [0.6 0.6 0.6], 'filled', 'DisplayName', 'Raw Tire Points');

% Live Line Handle (Plots the blue line live as simulations complete)
h_line = plot(NaN, NaN, 'b-', 'LineWidth', 2.5, 'DisplayName', sprintf('Envelope (\\delta = %d\\circ)', steer_deg));

legend('Location', 'best');

% --- 3. Iteration Loop ---
for b = 1:num_beta
    current_beta = beta_deg_array(b);
    init_vy = v_target * tan(deg2rad(current_beta));
    
    simIn = Simulink.SimulationInput(modelName);
    simIn = simIn.setModelParameter('SimulationMode', 'accelerator');
    simIn = simIn.setModelParameter('StopTime', '0.05'); 
    simIn = simIn.setModelParameter('MaskedZcDiagnostic', 'none');
    
    simIn = simIn.setVariable('init_vx', v_target);
    simIn = simIn.setVariable('init_vy', init_vy);
    simIn = simIn.setVariable('init_r', 0);           
    simIn = simIn.setVariable('vel_ggv', v_target);   
    simIn = simIn.setVariable('steer_ggv', steer_rad); 
    
    out = sim(simIn);
    
    % Extract Data safely
    try lat_accel_trace = out.Lateral_accln_sensor.Data; catch, lat_accel_trace = out.Lateral_accln.Data; end
    yaw_moment_trace = out.Yaw_moment.Data;
    try time_array = out.tout; catch, time_array = out.get('tout'); end
    
    % Take snapshot at t = 0.02s (tire relaxation saturation)
    t_snapshot = 0.02;
    snap_idx = find(time_array >= t_snapshot, 1);
    if isempty(snap_idx), snap_idx = length(time_array); end 
    
    ay_val = lat_accel_trace(snap_idx);
    mz_val = yaw_moment_trace(snap_idx);
    
    % NaN/Inf Guard
    if isnan(ay_val) || isinf(ay_val), ay_val = 0; end
    if isnan(mz_val) || isinf(mz_val), mz_val = 0; end
    
    curve_ay(b) = ay_val;
    curve_mz(b) = mz_val;
    
    % LIVE PLOT UPDATE (Updates both scatter and line live)
    h_scatter.XData = curve_ay(1:b);
    h_scatter.YData = curve_mz(1:b);
    h_line.XData    = curve_ay(1:b);
    h_line.YData    = curve_mz(1:b);
    drawnow; 
    
    fprintf('Beta = %3d deg | Ay = %6.2f | Mz = %7.2f\n', current_beta, curve_ay(b), curve_mz(b));
end

set_param(modelName, 'FastRestart', 'off');

% --- 4. CLEAN ENVELOPE TRIMMING ---
% Find the absolute lateral limits to slice off the curling ends
[~, idx_left_limit]  = min(curve_ay);
[~, idx_right_limit] = max(curve_ay);

start_idx = min(idx_left_limit, idx_right_limit);
end_idx   = max(idx_left_limit, idx_right_limit);

clean_ay = curve_ay(start_idx:end_idx);
clean_mz = curve_mz(start_idx:end_idx);

% Final update: Lock the line strictly to the clean envelope
h_line.XData = clean_ay;
h_line.YData = clean_mz;

% Highlight Anchor Point (Beta = 0)
idx_zero = find(beta_deg_array == 0, 1);
if ~isempty(idx_zero)
    scatter(curve_ay(idx_zero), curve_mz(idx_zero), 90, 'r', 'filled', 'DisplayName', 'Anchor: \beta = 0\circ');
end

fprintf('\nDone. Clean Snapshot YMD envelope updated.\n');