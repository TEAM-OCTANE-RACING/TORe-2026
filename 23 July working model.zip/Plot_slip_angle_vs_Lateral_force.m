% =========================================================================
% SCRIPT: PURE SLIP LATERAL FORCE SWEEP (ASYMMETRY CHECK)
% Evaluates pure lateral force to identify ply steer and conicity shifts
% =========================================================================

%% --- 0. PRE-FLIGHT CHECK ---
fprintf('=== LATERAL FORCE ASYMMETRY ANALYSIS ===\n');
if evalin('base', '~exist(''TireData'', ''var'')')
    error('Missing variables: Ensure TireData is loaded in the base workspace.');
end

% Load parameters directly from the workspace
TireData = evalin('base', 'TireData');

%% --- 1. SWEEP CONFIGURATION ---
Fz_test     = TireData.FNOMIN;       % Test at nominal vertical load
camber_test = 0;                     % Test at exactly zero camber
slip_deg    = linspace(-30, 30, 100)'; 
slip_rad    = deg2rad(slip_deg);

fprintf('Evaluating Tire Lateral Force Sweep...\n');
fprintf('Load (Fz): %.0f N | Camber: %.1f deg\n', Fz_test, camber_test);

%% --- 2. EXECUTE TIRE MATH ---
Fy_sweep = calc_pure_lateral_force(Fz_test, slip_rad, camber_test, TireData);

% Find Force at exactly 0 degrees to isolate the shift
% Evaluate the force explicitly at EXACTLY 0.000 radians
Fy_at_zero = calc_pure_lateral_force(Fz_test, 0.0, camber_test, TireData);

fprintf('-> Lateral Force at 0 deg slip: %8.2f N\n', Fy_at_zero);
if abs(Fy_at_zero) > 1
    fprintf('-> NOTE: Intrinsic lateral pull detected (Conicity/Ply Steer is active).\n');
else
    fprintf('-> NOTE: Tire is laterally symmetric.\n');
end

%% --- 3. VISUALIZATION ---
figure('Name', 'Tire Lateral Force Asymmetry', 'Color', 'w', 'Position', [150 200 800 500]);
hold on; grid on;

% Zero axes for clean visual reference
plot([-15 15], [0 0], 'k-', 'LineWidth', 1.2, 'HandleVisibility', 'off');
plot([0 0], [min(Fy_sweep) max(Fy_sweep)], 'k-', 'LineWidth', 1.2, 'HandleVisibility', 'off');

% Main Sweep Plot
plot(slip_deg, Fy_sweep, '-b', 'LineWidth', 2.5, 'DisplayName', 'Tire Lateral Force (F_y)');

% Highlight the Zero-Crossing Offset
scatter(0, Fy_at_zero, 80, 'r', 'filled', 'DisplayName', 'Force at 0^\circ Slip');

% Dynamically place the text slightly offset from the marker
text_y_offset = (max(Fy_sweep) - min(Fy_sweep)) * 0.05;
text(0.5, Fy_at_zero - text_y_offset, sprintf(' F_y = %.2f N\n (Intrinsic Shift)', Fy_at_zero), ...
    'Color', 'r', 'FontSize', 11, 'FontWeight', 'bold');

title('Slip Angle vs Lateral Force (Intrinsic Asymmetry Check)', 'FontSize', 13);
xlabel('Slip Angle \alpha (deg)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Lateral Force F_y (N)', 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'northwest');

% =========================================================================
% LOCAL ENGINE (Evaluates Vectorized MF5.2 Lateral Force)
% =========================================================================
function Fy0 = calc_pure_lateral_force(Fz, slip_angles, camber_angles, TireData)
    p = TireData;
    s = TireData.Scales;
    Fz0 = p.FNOMIN;
    
    Fz_safe = max(Fz, 0);
    dfz = (Fz_safe - Fz0) / Fz0;
    
    Cy = p.PCY1 * s.LCY;
    
    % Friction Coeff Mu_y
    mu_y_base = (p.PDY1 + p.PDY2 .* dfz) .* (1 - p.PDY3 .* camber_angles.^2) .* s.LMUY;
    Dy = mu_y_base .* Fz_safe;
    
    % Cornering Stiffness Ky
    Ky = p.PKY1 .* Fz0 .* sin(2 .* atan(Fz_safe ./ (p.PKY2 .* Fz0))) .* (1 - p.PKY3 .* abs(camber_angles)) .* s.LKY;
    
    % Poly fallback check (if PKY2 implies poly form)
    if (Ky(1) < 1)
        Ky = Fz_safe .* (p.PKY1 + p.PKY2 .* dfz) .* s.LKY;
    end
    
    By = Ky ./ (Cy .* Dy + 1e-6);
    
    % Lateral Shifts (Ply Steer and Conicity)
    Shy = (p.PHY1 + p.PHY2 .* dfz) .* s.LHY;
    Svy = Fz_safe .* (p.PVY1 + p.PVY2 .* dfz) .* s.LVY;
    
    a_s = slip_angles + Shy;
    
    % Curvature Ey
    Ey = (p.PEY1 + p.PEY2 .* dfz) .* (1 - (p.PEY3 + p.PEY4 .* camber_angles) .* sign(a_s)) .* s.LEY;
    Ey(Ey > 1) = 1;
    
    By_a = By .* a_s;
    
    % Final Pure Lateral Force
    Fy0 = -(Dy .* sin(Cy .* atan(By_a - Ey .* (By_a - atan(By_a)))) + Svy);
end