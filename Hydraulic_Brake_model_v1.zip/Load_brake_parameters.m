% Load Brake parameters:

brakes = struct();                                 % Initializing empty structure.

brakes.max_brk_travel_deg = 60;                    % Max brake travel in degrees(till BOTS).
brakes.max_MC_travel = 25;                         % Max MC travel in mm.
brakes.piston_dia = 31.8/1000;                     % Piston diameter.
brakes.MC_dia = 18.8/1000;                         % Master cylinder diameter.
brakes.MC_area = pi*(brakes.MC_dia^2)/4;
brakes.piston_area = pi*(brakes.piston_dia^2)/4;   % Area of piston.
brakes.Area_f = 4*brakes.piston_area;              % Effective area for braking in front(4 piston).
brakes.Area_r = 2*brakes.piston_area;              % Effective area for braking in rear(2-piston).
brakes.K_brk_spring =  36.865;                     % Brake paddle spring stiffness (N/rad).
brakes.K_MC = 7.6666;                              % Master cylinder spring stiffness(N/mm).
brakes.Leverage = 4.6;                             % Mechanical advantage between brake paddle and MC.
brakes.Mu_disk = 0.35;                             % Coefficient of friction of brake disk.
brakes.Eff_braking_radius_f = 69.3/1000;           % Effective radius at which calipar applies force(in m).
brakes.Eff_braking_radius_r = 81.05/1000;          % Effective radius at which calipar applies force(in m).
brakes.F_driver_max = 375.64;                      % Max Brake force by driver.